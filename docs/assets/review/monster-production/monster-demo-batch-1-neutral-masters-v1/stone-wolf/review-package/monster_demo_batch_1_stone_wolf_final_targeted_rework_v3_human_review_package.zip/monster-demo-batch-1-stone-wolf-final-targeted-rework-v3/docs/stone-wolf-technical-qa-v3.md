# Stone Wolf — Technical QA v3

- PNG RGBA 8-bit, 640×960: PASS
- Transparent borders: PASS
- Alpha bounds: 502×470 +69+385
- Baseline half-open Y: 855
- Exact binary comparison: CHANGED
- Mean absolute RGB difference: 10.7033
- dHash distance: 12
- Human approval: pending
