# Skeleton Neutral Master Style Polish v3 — Technical QA

## Scope

v3 is a surface-and-form polish of the v2 candidate. Identity, silhouette, proportions, skull/body/hand/foot/mallet scale, overall pose, role, and equipment complexity remain locked.

## Polish findings

- Material: bone has richer warm/cool variation, cleaner broad highlights, soft ambient bounce, and greater painted depth without plastic or realistic-PBR gloss.
- Bone color: creamy ivory transitions into muted honey light and restrained cool-taupe occlusion more smoothly.
- Eye sockets: warm-brown bounce and gentler gradients reduce the heavy black-void reading; no glow or emissive eyes were added.
- Ribcage: rounded fantasy forms and more regular spacing improve readability while retaining the v2 footprint.
- Joints: elbows, knees, and ankles are cleaner and rounder without moving or resizing the limbs.
- Leather/cloth: belt, waist cloth, wrist wrap, and mallet binding retain the same complexity with richer handcrafted value separation.
- Overall rendering: material hierarchy, gradients, controlled light, and edge finish are closer to the approved Class 1 roster.

## Binary contract

- Candidate: `candidate/skeleton-neutral-master-style-polish-v3.png`
- SHA-256: `861369dbe72bd1742af7e1ff3aa4e4bf49de9ee216ff59b4723aab4add0a99a8`
- PNG, RGBA, 8-bit, 640×960
- Alpha bounds: `504×701 +46+154`
- Base bounds: `507×701 +44+154`
- Maximum alpha Y: `854`
- Half-open baseline: `855`
- Outer borders: fully transparent
- Visible chroma-key contamination: none detected
- Anchor candidate: `[0.5, 0.92]`
- RuntimeFlipX: compatible
- Runtime scale recommendation: `1.0`; review metadata only

## Readability validation

- Transparent-background review: PASS.
- Board-scale proxy: PASS.
- Warm dark-ground proxy: PASS.
- Silhouette comparison: PASS; pose, height, and baseline remain stable.
- Grayscale readability: PASS.

Internal quality estimates meet the requested 9.5 target range, but they are production QA estimates only and do not replace the user's visual decision.

## Limitations

- Board images are review proxies, not a board implementation.
- No Motion, Runtime, Combat, gameplay, balance, projectile, or VFX work was performed.
- Human visual approval remains pending.
