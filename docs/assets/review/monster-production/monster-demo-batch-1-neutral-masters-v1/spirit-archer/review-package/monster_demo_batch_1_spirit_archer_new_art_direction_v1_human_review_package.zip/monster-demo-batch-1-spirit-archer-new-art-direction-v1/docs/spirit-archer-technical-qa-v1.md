# Spirit Archer — Technical QA v1

- Old SHA-256: `d943c84ffe5f9538f75c1a28e38b3302da513809a530d8ff37b244d4c2560459`
- New SHA-256: `2438dfc1047106bc51549cda4cdb60c9cf450d7b1cb1ed38785ffac533ed479e`
- Binary comparison: **CHANGED**
- PNG RGBA 8-bit 640×960: PASS
- Alpha bounds: `{'x': 103, 'y': 225, 'width': 434, 'height': 630}`
- Maximum alpha Y: `854`
- Half-open baseline Y: `855`
- Fully transparent outer borders: PASS
- Chroma contamination: PASS (`0` magenta pixels inside alpha)
- Crop/containment: PASS
- Bow/body continuity: Internal visual PASS
- RuntimeFlipX compatibility: PASS (recommendation; Runtime not tested)
- Human visual approval: PENDING
- Motion/Runtime/Game/Combat/GitHub work: NOT PERFORMED
