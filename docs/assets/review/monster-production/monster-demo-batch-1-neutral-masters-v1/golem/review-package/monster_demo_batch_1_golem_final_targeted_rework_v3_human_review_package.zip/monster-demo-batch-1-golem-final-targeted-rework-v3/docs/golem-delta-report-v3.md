# Golem — Final Targeted Rework v3

Old SHA-256: `82a83cb6cee3915e3b505740af1745ea2b3402e0ef2d8bc0f6efa20b1a8f4ea4`

New SHA-256: `a6f25abed97388c2f2d1572ed95581ef2a5dcb9b43b49d816fb4ed3e132af36a`

Exact binary comparison: **CHANGED**

Visible changes:

- softened brow and eye-slot authority while preserving the embedded face
- shifted expression toward curious-alert ordinary monster
- warmed stone bounce and enriched painterly material depth
- rounded selected face/shoulder transitions without changing scale or silhouette
- reduced imposing hard contrast while preserving fists, feet and body mass

Human approval remains pending.
