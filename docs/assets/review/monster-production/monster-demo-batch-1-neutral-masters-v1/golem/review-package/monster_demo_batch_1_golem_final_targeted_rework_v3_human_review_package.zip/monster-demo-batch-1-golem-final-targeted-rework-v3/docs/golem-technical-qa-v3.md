# Golem — Technical QA v3

- PNG RGBA 8-bit, 640×960: PASS
- Transparent borders: PASS
- Alpha bounds: 545×519 +47+336
- Baseline half-open Y: 855
- Exact binary comparison: CHANGED
- Mean absolute RGB difference: 10.3047
- dHash distance: 3
- Human approval: pending
